const STRAZH_API = 'https://strazh-server.onrender.com';

function getLicenseKey() {
  return new Promise(resolve => {
    chrome.storage.local.get(['strazh_license'], r => resolve(r.strazh_license || ''));
  });
}

function createButton() {
  const btn = document.createElement('div');
  btn.className = 'strazh-btn';
  btn.innerHTML = `<span class="strazh-icon">🛡</span><span>Проверить в Страже</span>`;
  btn.style.cssText = `
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; margin-left: 8px;
    background: #fff3f3; border: 1.5px solid #e84040;
    border-radius: 6px; cursor: pointer;
    font-size: 13px; font-weight: 600; color: #c0392b;
    font-family: 'Google Sans', Roboto, sans-serif;
    transition: all 0.2s; white-space: nowrap;
    user-select: none;
  `;
  btn.addEventListener('mouseenter', () => {
    btn.style.background = '#fde8e8';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.background = '#fff3f3';
  });
  return btn;
}

function createResultBadge(result) {
  const colors = {
    safe: { bg: '#f0fff4', border: '#2ecc71', text: '#1a7a40', icon: '✅' },
    warning: { bg: '#fffbf0', border: '#f39c12', text: '#8a5c00', icon: '⚠️' },
    danger: { bg: '#fff3f3', border: '#e74c3c', text: '#c0392b', icon: '🚫' }
  };
  const c = colors[result.verdict] || colors.warning;
  const badge = document.createElement('div');
  badge.className = 'strazh-result';
  badge.style.cssText = `
    margin: 10px 0 4px; padding: 12px 16px;
    background: ${c.bg}; border: 1px solid ${c.border};
    border-radius: 8px; font-family: 'Google Sans', Roboto, sans-serif;
  `;
  badge.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
      <span style="font-size:18px">${c.icon}</span>
      <span style="font-weight:700;font-size:14px;color:${c.text}">${result.verdict_label}</span>
      <span style="margin-left:auto;font-size:13px;font-weight:700;color:${c.text}">Риск: ${result.risk_score}/10</span>
    </div>
    <div style="font-size:13px;color:#444;line-height:1.6">${result.summary}</div>
    ${result.findings && result.findings.length ? `
      <div style="margin-top:8px;display:flex;flex-direction:column;gap:4px;">
        ${result.findings.slice(0,3).map(f => `
          <div style="font-size:12px;color:#555;display:flex;gap:6px;">
            <span>${f.level==='danger'?'🚫':f.level==='warning'?'⚡':'✅'}</span>
            <span><strong>${f.title}</strong> — ${f.description}</span>
          </div>
        `).join('')}
      </div>
    ` : ''}
  `;
  return badge;
}

function createLoadingBadge() {
  const badge = document.createElement('div');
  badge.className = 'strazh-loading';
  badge.style.cssText = `
    margin: 10px 0 4px; padding: 12px 16px;
    background: #f8f9ff; border: 1px solid #dde;
    border-radius: 8px; font-family: 'Google Sans', Roboto, sans-serif;
    font-size: 13px; color: #666;
    display: flex; align-items: center; gap: 10px;
  `;
  badge.innerHTML = `<span style="font-size:18px">🛡</span><span>Страж анализирует письмо...</span>`;
  return badge;
}

async function analyzeEmail(emailBody, emailFrom, emailSubject) {
  const licenseKey = await getLicenseKey();
  const content = `От: ${emailFrom}
Тема: ${emailSubject}
Текст письма:
${emailBody.substring(0, 3000)}`;

  const resp = await fetch(STRAZH_API + '/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      type: 'электронное письмо (email)',
      content,
      ...(licenseKey ? { license_key: licenseKey } : {})
    })
  });

  if (resp.status === 429) throw new Error('Лимит проверок исчерпан. Оформи подписку на strazh-server.onrender.com');
  if (!resp.ok) throw new Error('Ошибка сервера');
  return await resp.json();
}

function getEmailData(emailEl) {
  const fromEl = emailEl.querySelector('[email]') || emailEl.querySelector('.gD');
  const subjectEl = document.querySelector('h2.hP');
  const bodyEl = emailEl.querySelector('.a3s') || emailEl.querySelector('[data-message-id]');

  return {
    from: fromEl ? (fromEl.getAttribute('email') || fromEl.textContent) : 'неизвестно',
    subject: subjectEl ? subjectEl.textContent : 'без темы',
    body: bodyEl ? bodyEl.innerText : ''
  };
}

function injectButton(emailEl) {
  if (emailEl.querySelector('.strazh-btn')) return;

  const toolbarSelectors = ['.ams.bkH', '.iN', '.ade', 'td.gF.gK'];
  let toolbar = null;
  for (const sel of toolbarSelectors) {
    toolbar = emailEl.querySelector(sel);
    if (toolbar) break;
  }
  if (!toolbar) {
    toolbar = emailEl.querySelector('[role="toolbar"]');
  }
  if (!toolbar) return;

  const btn = createButton();
  toolbar.appendChild(btn);

  btn.addEventListener('click', async () => {
    const existing = emailEl.querySelector('.strazh-result, .strazh-loading, .strazh-error');
    if (existing) existing.remove();

    const body = emailEl.querySelector('.a3s, .ii.gt');
    if (!body) return;

    const loading = createLoadingBadge();
    body.parentNode.insertBefore(loading, body);

    try {
      const { from, subject, body: bodyText } = getEmailData(emailEl);
      const result = await analyzeEmail(bodyText, from, subject);
      loading.remove();
      const badge = createResultBadge(result);
      body.parentNode.insertBefore(badge, body);
    } catch (err) {
      loading.remove();
      const errBadge = document.createElement('div');
      errBadge.className = 'strazh-error';
      errBadge.style.cssText = `margin:10px 0 4px;padding:10px 14px;background:#fff8f0;border:1px solid #f39c12;border-radius:8px;font-size:13px;color:#8a5c00;`;
      errBadge.textContent = '⚠️ ' + err.message;
      body.parentNode.insertBefore(errBadge, body);
    }
  });
}

function scanForEmails() {
  const emailContainers = document.querySelectorAll('.adn.ads, .nH.if, [data-legacy-message-id]');
  emailContainers.forEach(el => injectButton(el));
}

const observer = new MutationObserver(() => {
  scanForEmails();
});

observer.observe(document.body, { childList: true, subtree: true });
scanForEmails();
